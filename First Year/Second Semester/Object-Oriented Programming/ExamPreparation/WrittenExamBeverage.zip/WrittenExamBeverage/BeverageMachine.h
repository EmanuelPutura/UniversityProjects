//
// Created by Emanuel on 20.06.2021.
//

#ifndef WRITTENEXAMBEVERAGE_BEVERAGEMACHINE_H
#define WRITTENEXAMBEVERAGE_BEVERAGEMACHINE_H

#include <string>

class BeverageMachine {
public:
    void prepare(const std::string& beverageType, int milkCount);
};


#endif //WRITTENEXAMBEVERAGE_BEVERAGEMACHINE_H
