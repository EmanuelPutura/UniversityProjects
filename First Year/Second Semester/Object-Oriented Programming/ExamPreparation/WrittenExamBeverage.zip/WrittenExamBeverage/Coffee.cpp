//
// Created by Emanuel on 20.06.2021.
//

#include "Coffee.h"

Coffee::Coffee() : Beverage("Coffee") {
}

double Coffee::price() {
    return 2.5;
}
