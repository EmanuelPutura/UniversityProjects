//
// Created by Emanuel on 20.06.2021.
//

#include "Tea.h"

Tea::Tea() : Beverage("Tea") {
}

double Tea::price() {
    return 1.5;
}
